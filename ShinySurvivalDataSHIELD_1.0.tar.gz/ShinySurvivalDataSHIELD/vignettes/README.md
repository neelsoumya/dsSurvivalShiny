Vignettes, training material and tutorials
