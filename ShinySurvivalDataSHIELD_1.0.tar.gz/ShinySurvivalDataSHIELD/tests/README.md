tests for survival models
