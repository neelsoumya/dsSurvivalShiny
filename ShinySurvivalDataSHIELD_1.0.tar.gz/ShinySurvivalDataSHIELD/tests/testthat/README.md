testthat directory with smoke tests for survival models
