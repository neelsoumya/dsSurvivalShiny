R and rmarkdown files for GUI


* server.R and ui.R

    * R scripts for shiny server
    
* utilities.R

   * helper functions
   
* log_model_summary.rmd and log_data_summary.rmd

   * R markdown to generate reports
   
* redmeat_survival_ownVM.R

   * script to load data and perform filtering and quality control in DataSHIELD 
